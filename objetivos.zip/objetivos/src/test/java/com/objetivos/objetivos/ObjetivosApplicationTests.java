package com.objetivos.objetivos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObjetivosApplicationTests {

	@Test
	void contextLoads() {
	}

}
