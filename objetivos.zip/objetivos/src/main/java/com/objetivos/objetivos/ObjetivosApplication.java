package com.objetivos.objetivos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObjetivosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObjetivosApplication.class, args);
	}

}
